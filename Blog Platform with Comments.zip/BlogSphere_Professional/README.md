# BlogSphere Pro

A professional Django + Django REST Framework blogging platform with a polished responsive frontend.

## Included
- Responsive Home/Discover page
- Search and sorting
- Registration and JWT login
- Create, edit and delete stories
- Comments and comment deletion
- Author-only post permissions
- Dark/light theme
- Pagination and empty/error states
- Django Admin
- SQLite by default and MySQL configuration
- Initial database migration

## Run
```bash
pip install -r requirements.txt
python manage.py check
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open: http://127.0.0.1:8000/

Pages:
- `/` — Home / discover
- `/login/` — Login
- `/register/` — Registration
- `/write/` — Create or edit a story
- `/post/?id=1` — Story + comments
- `/admin/` — Django administration

## API
- `POST /api/auth/register/`
- `POST /api/auth/login/`
- `POST /api/auth/refresh/`
- `GET|POST /api/posts/`
- `GET|PATCH|DELETE /api/posts/<id>/`
- `GET|POST /api/posts/<id>/comments/`
- `DELETE /api/comments/<id>/`

## Verification
Python source compilation was checked with `python -m compileall`. Frontend asset references, page routes, templates and API route wiring were reviewed. Full Django runtime checks require installing the dependencies in `requirements.txt`; this build environment does not include Django.
