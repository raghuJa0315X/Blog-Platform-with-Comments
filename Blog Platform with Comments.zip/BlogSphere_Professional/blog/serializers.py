from django.contrib.auth.models import User
from rest_framework import serializers
from .models import Post, Comment

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model=User
        fields=['id','username','email']

class RegisterSerializer(serializers.ModelSerializer):
    password=serializers.CharField(write_only=True,min_length=6)
    class Meta:
        model=User
        fields=['username','email','password']
    def create(self, validated_data):
        return User.objects.create_user(**validated_data)

class CommentSerializer(serializers.ModelSerializer):
    author=UserSerializer(read_only=True)
    class Meta:
        model=Comment
        fields=['id','post','author','content','created_at']
        read_only_fields=['post','author','created_at']

class PostSerializer(serializers.ModelSerializer):
    author=UserSerializer(read_only=True)
    comments=CommentSerializer(many=True,read_only=True)
    class Meta:
        model=Post
        fields=['id','title','content','author','created_at','updated_at','comments']
