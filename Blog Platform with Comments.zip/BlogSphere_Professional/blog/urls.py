from django.urls import path
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from .views import RegisterView, PostListCreateView, PostDetailView, CommentListCreateView, CommentDeleteView

urlpatterns=[
 path('auth/register/',RegisterView.as_view()),
 path('auth/login/',TokenObtainPairView.as_view()),
 path('auth/refresh/',TokenRefreshView.as_view()),
 path('posts/',PostListCreateView.as_view()),
 path('posts/<int:pk>/',PostDetailView.as_view()),
 path('posts/<int:post_id>/comments/',CommentListCreateView.as_view()),
 path('comments/<int:pk>/',CommentDeleteView.as_view()),
]
