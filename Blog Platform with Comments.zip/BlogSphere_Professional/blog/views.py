from django.contrib.auth.models import User
from rest_framework import generics, permissions
from rest_framework_simplejwt.views import TokenObtainPairView
from .models import Post, Comment
from .serializers import RegisterSerializer, PostSerializer, CommentSerializer

class RegisterView(generics.CreateAPIView):
    queryset=User.objects.all()
    serializer_class=RegisterSerializer

class PostListCreateView(generics.ListCreateAPIView):
    queryset=Post.objects.select_related('author').prefetch_related('comments__author')
    serializer_class=PostSerializer
    def perform_create(self, serializer): serializer.save(author=self.request.user)
    def get_permissions(self):
        return [permissions.IsAuthenticated()] if self.request.method=='POST' else [permissions.AllowAny()]

class PostDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset=Post.objects.select_related('author').prefetch_related('comments__author')
    serializer_class=PostSerializer
    def get_permissions(self):
        if self.request.method in ['PUT','PATCH','DELETE']: return [IsAuthorOrReadOnly()]
        return [permissions.AllowAny()]

class IsAuthorOrReadOnly(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        return request.method in permissions.SAFE_METHODS or obj.author == request.user

class CommentListCreateView(generics.ListCreateAPIView):
    serializer_class=CommentSerializer
    def get_queryset(self): return Comment.objects.filter(post_id=self.kwargs['post_id']).select_related('author')
    def perform_create(self, serializer):
        serializer.save(post_id=self.kwargs['post_id'],author=self.request.user)
    def get_permissions(self):
        return [permissions.IsAuthenticated()] if self.request.method=='POST' else [permissions.AllowAny()]

class CommentDeleteView(generics.DestroyAPIView):
    queryset=Comment.objects.all()
    serializer_class=CommentSerializer
    permission_classes=[permissions.IsAuthenticated]
    def perform_destroy(self, instance):
        if instance.author != self.request.user:
            from rest_framework.exceptions import PermissionDenied
            raise PermissionDenied('You can delete only your own comments.')
        instance.delete()
